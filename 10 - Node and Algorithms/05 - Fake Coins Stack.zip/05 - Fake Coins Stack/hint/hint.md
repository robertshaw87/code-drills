* The minimum number of scale uses is 1

* Remember, you can split the stacks, so you're weight portions of each stack of coins