* If you define an anonymous function within another function, your anonymous function will have access to the variables defined within the parent function.

* The return value of a function can be anything, even another function.

* You can invoke a functiion immediately after defining it.
