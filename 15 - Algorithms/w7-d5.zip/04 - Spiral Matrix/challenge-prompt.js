// Spiral iteration through a matrix


// This function takes in a `m` x `n` matrix represented as an array 
// of `m` sub-arrays, each of which contain `n` elements and returns
// all the elements of the matrix starting with the element in the
// top left and clockwise spiraling inward
function spiralIter(matrix) {
  // -------------------- Your Code Here --------------------






  // -------------------- End Code Area ---------------------
}

// This export is for testing the function
module.exports = spiralIter;